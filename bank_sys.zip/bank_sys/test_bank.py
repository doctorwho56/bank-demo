import unittest
import os
from bank import BankAccount, BankSystem


class TestBankAccount(unittest.TestCase):
	def test_initial_balance(self):
		# check whether the value error can be caught expectedly if initial balance value is negative
		with self.assertRaises(ValueError):
			BankAccount("test", -100)

	def test_deposit(self):
		# test for depositing money
		acc = BankAccount("test", 100)
		acc.deposit(50)
		self.assertEqual(acc.balance, 150)
		with self.assertRaises(ValueError):
			acc.deposit(-10)

	def test_withdraw(self):
		# test for withdrawing money
		acc = BankAccount("test", 100)
		self.assertTrue(acc.withdraw(50))
		self.assertEqual(acc.balance, 50)
		self.assertFalse(acc.withdraw(100))
		with self.assertRaises(ValueError):
			acc.withdraw(-10)


class TestBankSystem(unittest.TestCase):
	def setUp(self):
		# load initial configuration
		self.bank = BankSystem()
		self.bank.create_account("Alice", 1000)
		self.bank.create_account("Bob", 500)

	def test_create_account(self):
		# test for duplicate account error catching
		with self.assertRaises(ValueError):
			self.bank.create_account("Alice", 200)

	def test_transfer(self):
		# test for money transaction
		self.assertTrue(self.bank.transfer("Alice", "Bob", 200))
		self.assertEqual(self.bank.get_account("Alice").balance, 800)
		self.assertEqual(self.bank.get_account("Bob").balance, 700)

		self.assertFalse(self.bank.transfer("Alice", "Bob", 900))
		self.assertFalse(self.bank.transfer("Alice", "Charlie", 100))

	def test_save_load(self):
		# test for save system state to csv
		self.bank.save_to_csv("test.csv")
		# os.remove("test.csv")


if __name__ == '__main__':
	unittest.main()
