import csv

class BankAccount:
	def __init__(self, name, balance):
		if balance < 0:
			raise ValueError("Initial balance cannot be negative")
		self.name = name
		self.balance = balance

	def deposit(self, amount):
		if amount <= 0:
			raise ValueError("Deposit amount must be positive")
		self.balance += amount

	def withdraw(self, amount):
		if amount <= 0:
			raise ValueError("Withdrawal amount must be positive")
		if amount > self.balance:
			return False
		self.balance -= amount
		return True


class BankSystem:
	def __init__(self):
		self.accounts = {}

	def create_account(self, name, initial_balance):
		if name in self.accounts:
			raise ValueError("Account already exists")
		if initial_balance < 0:
			raise ValueError("Initial balance cannot be negative")
		self.accounts[name] = BankAccount(name, initial_balance)

	def get_account(self, name):
		return self.accounts.get(name)

	def transfer(self, from_name, to_name, amount):
		if amount <= 0:
			return False
		from_account = self.get_account(from_name)
		to_account = self.get_account(to_name)
		if not from_account or not to_account:
			return False
		if from_account.withdraw(amount):
			try:
				to_account.deposit(amount)
			except ValueError:
				from_account.balance += amount  # Rollback withdrawal
				return False
			return True
		return False

	def save_to_csv(self, filename):
		with open(filename, 'w', newline='') as csvfile:
			writer = csv.DictWriter(csvfile, fieldnames=['name', 'balance'])
			writer.writeheader()
			for account in self.accounts.values():
				writer.writerow({'name': account.name, 'balance': account.balance})
